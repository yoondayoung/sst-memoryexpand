var structSST_1_1StatOutputPy__t =
[
    [ "id", "structSST_1_1StatOutputPy__t.html#a012dcfc66bc6aa77c71bd554651dd730", null ],
    [ "ptr", "structSST_1_1StatOutputPy__t.html#a3eca95ab65e0a9cd298cadb83e79c95d", null ]
];