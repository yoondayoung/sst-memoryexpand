var structSST_1_1ELI_1_1MethodDetect =
[
    [ "type", "structSST_1_1ELI_1_1MethodDetect.html#a392e75693822ec66803801a90e735d1c", null ]
];