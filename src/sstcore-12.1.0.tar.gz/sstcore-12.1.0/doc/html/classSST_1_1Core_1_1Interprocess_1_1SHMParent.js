var classSST_1_1Core_1_1Interprocess_1_1SHMParent =
[
    [ "SHMParent", "classSST_1_1Core_1_1Interprocess_1_1SHMParent.html#a355543f6b11992e93963f2eda05d598d", null ],
    [ "~SHMParent", "classSST_1_1Core_1_1Interprocess_1_1SHMParent.html#a9c53ed99adf9501dc13cdb0ce4137dc1", null ],
    [ "getRegionName", "classSST_1_1Core_1_1Interprocess_1_1SHMParent.html#aac7ad6bab0ed47211e5eec3d571312bf", null ],
    [ "getTunnel", "classSST_1_1Core_1_1Interprocess_1_1SHMParent.html#ae4aec2e9eb7fc0e3689c08aedbc02501", null ]
];