var classSST_1_1Core_1_1Serialization_1_1pvt_1_1raw__ptr__wrapper =
[
    [ "raw_ptr_wrapper", "classSST_1_1Core_1_1Serialization_1_1pvt_1_1raw__ptr__wrapper.html#ac39740ed3d8fbdbd550c46d6be9327df", null ],
    [ "bufptr", "classSST_1_1Core_1_1Serialization_1_1pvt_1_1raw__ptr__wrapper.html#ad9a3c312d595de2af95804137ecad667", null ]
];