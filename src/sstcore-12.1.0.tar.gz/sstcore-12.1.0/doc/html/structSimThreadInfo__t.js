var structSimThreadInfo__t =
[
    [ "build_time", "structSimThreadInfo__t.html#aedfea2826f1d81c5826057b44d958b11", null ],
    [ "config", "structSimThreadInfo__t.html#aed0dd2b53297dab577365b132d1e0b83", null ],
    [ "current_tv_depth", "structSimThreadInfo__t.html#a0e960b60b1a3e9c2f0e2b76ae25446af", null ],
    [ "graph", "structSimThreadInfo__t.html#ac467dfbf947f167cf453db4b6605dade", null ],
    [ "max_tv_depth", "structSimThreadInfo__t.html#a31f84e78f793c2e9e7686952f1287403", null ],
    [ "min_part", "structSimThreadInfo__t.html#a5ec27898c5f534616705cb60d14378a1", null ],
    [ "myRank", "structSimThreadInfo__t.html#a74daaf7df473b0c9601b6c90e849b67a", null ],
    [ "run_time", "structSimThreadInfo__t.html#a7200f4fa12cc7f0699e4af1b612d428e", null ],
    [ "simulated_time", "structSimThreadInfo__t.html#ad99c3624e24ea64a20071063440e4ecf", null ],
    [ "sync_data_size", "structSimThreadInfo__t.html#a4c7360acf8b66895db5c646aaad3d675", null ],
    [ "world_size", "structSimThreadInfo__t.html#a12c5b4ba5f43c3289272a6945a36304f", null ]
];